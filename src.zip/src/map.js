// [1,2,3,4,5,6]  ----> [2,4,6,8,10]

const base = [1,2,3,4,5,6]

const tab2 = base.map((numeroBase)=>{
        return numeroBase * 2
}) 

